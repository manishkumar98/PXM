import openai

# Set your API key here. You can obtain your API key from the OpenAI platform.
api_key = "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"

# Initialize the OpenAI client
openai.api_key = api_key

def chat_with_gpt3(prompt):
    try:
        response = openai.Completion.create(
            engine="text-davinci-002",  # You can use "text-davinci-002" for ChatGPT
            prompt=prompt,
            max_tokens=50,  # Adjust the response length as needed
        )
        return response.choices[0].text.strip()
    except Exception as e:
        return str(e)

# Example usage
user_input = input("You: ")
while user_input.lower() != 'exit':
    response = chat_with_gpt3(f"You: {user_input}\n")
    print(f"AI: {response}")
    user_input = input("You: ")
