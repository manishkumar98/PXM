import pandas as pd

# Create a DataFrame from the sample data
df = pd.DataFrame(fashion_data)
