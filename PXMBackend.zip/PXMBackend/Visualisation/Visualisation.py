import matplotlib.pyplot as plt

# Create plots or charts to visualize data
plt.plot(df['product_name'], df['sales'])
