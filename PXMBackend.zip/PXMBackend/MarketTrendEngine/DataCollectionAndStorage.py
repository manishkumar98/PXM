# Sample data (you would replace this with real data sources)
fashion_data = [
    {"product_id": 1, "product_name": "Dress", "sales": 100, "reviews": 50, "sentiment": 0.8},
    # Add more data
]
