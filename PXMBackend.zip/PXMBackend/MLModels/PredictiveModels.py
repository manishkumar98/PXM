from sklearn.linear_model import LinearRegression

# Build a linear regression model
model = LinearRegression()
model.fit(X, y)
