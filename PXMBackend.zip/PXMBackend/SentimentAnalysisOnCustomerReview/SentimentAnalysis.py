from textblob import TextBlob

# Analyze sentiment
df['sentiment_score'] = df['reviews'].apply(lambda review: TextBlob(review).sentiment.polarity)
